import setuptools
setuptools.setup()

